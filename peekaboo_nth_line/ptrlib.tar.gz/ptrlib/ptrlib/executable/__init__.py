from ptrlib.executable.elf import *
from ptrlib.executable.pe import *
